import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  deleteDoc, 
  query, 
  where 
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { sanitizeFirestoreData } from './firestoreUtils';
import { fetchCompanyReleasedModules } from '../services/ModuleCatalogService';
import { ClientTenant, PlatformModule, TenantModulePermissions } from '../master-admin/types/master';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return errInfo;
}

export const COLLECTIONS = {
  EMPRESAS: 'empresas',
  MODULOS: 'modulos',
  EMPRESA_MODULOS: 'empresa_modulos',
  USUARIOS: 'usuarios',
  VAGAS: 'vagas',
  CANDIDATOS: 'candidatos',
  CANDIDATURAS: 'candidaturas',
} as const;

export interface EmpresaFirestoreDoc {
  empresaId: string;
  nomeEmpresa: string;
  CNPJ: string;
  email: string;
  plano: string;
  status: string;
  dataCriacao: string;
  rawTenantData?: ClientTenant;
}

export interface ModuloFirestoreDoc {
  moduloId: string;
  nome: string;
  codigo: string;
  descricao: string;
  ativo: boolean;
  rawModuleData?: PlatformModule;
}

export interface EmpresaModuloDoc {
  id: string;
  empresaId: string;
  moduloId: string;
  ativo: boolean;
  dataLiberacao: string;
}

export interface UsuarioFirestoreDoc {
  uid: string;
  nome: string;
  email: string;
  role?: string;
  tipoUsuario?: 'MASTER' | 'EMPRESA' | 'CANDIDATO' | 'FUNCIONARIO' | 'COLABORADOR';
  empresaId?: string | null;
  ativo?: boolean;
  isMaster?: boolean;
  status?: string;
  permissions?: string[];
  dataCriacao?: string;
  createdAt?: string;
  updatedAt?: string;
}

/**
 * Utility to seed initial Firestore collections if empty.
 */
export async function seedFirestoreIfEmpty(): Promise<void> {
  // Seeds de desenvolvimento desativados conforme diretrizes de segurança de produção.
}

// ----------------------------------------------------------------------------
// EMPRESAS
// ----------------------------------------------------------------------------
export async function fetchEmpresasFirestore(): Promise<ClientTenant[]> {
  try {
    await seedFirestoreIfEmpty();
    const snap = await getDocs(collection(db, COLLECTIONS.EMPRESAS));
    if (!snap.empty) {
      const list: ClientTenant[] = [];
      snap.forEach(docSnap => {
        const data = docSnap.data() as EmpresaFirestoreDoc;
        if (data.rawTenantData) {
          list.push({
            ...data.rawTenantData,
            id: data.empresaId || docSnap.id,
            companyName: data.nomeEmpresa || data.rawTenantData.companyName,
            cnpj: data.CNPJ || data.rawTenantData.cnpj,
            ownerEmail: data.email || data.rawTenantData.ownerEmail
          });
        } else {
          const defaultModules: TenantModulePermissions = {
            vagas: true,
            headhunter: true,
            bancoTalentos: true,
            entrevistas: true,
            equipeInterna: true,
            consultorRH: false,
            feriasBeneficios: true,
            documentosAssinatura: true,
            auditoriaLogs: false,
            relatoriosAvancados: true,
            siteVagasPersonalizado: true
          };

          list.push({
            id: data.empresaId || docSnap.id,
            code: (data.nomeEmpresa || 'EMP').substring(0, 5).toUpperCase(),
            companyName: data.nomeEmpresa || 'Empresa Cadastrada',
            tradeName: data.nomeEmpresa || 'Empresa Cadastrada',
            cnpj: data.CNPJ || '00.000.000/0001-00',
            ownerName: 'Administrador',
            ownerEmail: data.email || 'admin@empresa.com.br',
            ownerPhone: '(11) 99999-8888',
            status: (data.status as any) || 'Ativo',
            maxUsers: 10,
            maxActiveJobs: 20,
            modules: defaultModules,
            branding: {
              primaryColor: '#2563EB',
              companyDisplayName: data.nomeEmpresa
            },
            metrics: {
              activeUsersCount: 1,
              totalJobsCreated: 0,
              totalTalentsStored: 0,
              totalDocumentsSigned: 0,
              storageUsedMB: 10,
              lastLoginAt: 'Hoje'
            },
            contract: {
              id: `ctr-${docSnap.id}`,
              contractNumber: `CTR-2026-${Math.floor(1000 + Math.random() * 9000)}`,
              planName: (data.plano as any) || 'Básico',
              monthlyFee: 1200,
              billingCycle: 'Mensal',
              startDate: data.dataCriacao || '2026-01-01',
              expirationDate: '2027-01-01',
              paymentMethod: 'Pix',
              autoRenew: true
            },
            createdAt: data.dataCriacao
          });
        }
      });
      return list;
    }
  } catch (err: any) {
    console.warn('Erro ao buscar empresas do Firestore:', err?.message || err);
  }

  return [];
}

export async function saveEmpresaFirestore(tenantData: Partial<ClientTenant>): Promise<void> {
  const empresaId = tenantData.id || `emp-${Date.now()}`;
  const empresaDocRef = doc(db, COLLECTIONS.EMPRESAS, empresaId);

  const docData: EmpresaFirestoreDoc = {
    empresaId,
    nomeEmpresa: tenantData.companyName || tenantData.tradeName || 'Empresa Nova',
    CNPJ: tenantData.cnpj || '00.000.000/0001-00',
    email: tenantData.ownerEmail || 'contato@empresa.com.br',
    plano: tenantData.contract?.planName || 'Básico',
    status: tenantData.status || 'Ativo',
    dataCriacao: tenantData.createdAt || new Date().toISOString().split('T')[0],
    rawTenantData: {
      ...tenantData,
      id: empresaId
    } as ClientTenant
  };

  try {
    await setDoc(empresaDocRef, sanitizeFirestoreData(docData), { merge: true });
    
    // Storing module mappings in `empresa_modulos`
    if (tenantData.modules) {
      for (const [moduleCode, isEnabled] of Object.entries(tenantData.modules)) {
        await saveEmpresaModuloFirestore(empresaId, moduleCode, !!isEnabled);
      }
    }
  } catch (err) {
    console.error('Erro ao salvar empresa no Firestore:', err);
  }
}

export async function deleteEmpresaFirestore(empresaId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, COLLECTIONS.EMPRESAS, empresaId));
  } catch (err) {
    console.error('Erro ao excluir empresa do Firestore:', err);
  }
}

// ----------------------------------------------------------------------------
// MÓDULOS
// ----------------------------------------------------------------------------
export async function fetchModulosFirestore(): Promise<PlatformModule[]> {
  try {
    await seedFirestoreIfEmpty();
    const snap = await getDocs(collection(db, COLLECTIONS.MODULOS));
    if (!snap.empty) {
      const list: PlatformModule[] = [];
      snap.forEach(docSnap => {
        const data = docSnap.data() as ModuloFirestoreDoc;
        if (data.rawModuleData) {
          list.push({
            ...data.rawModuleData,
            id: data.moduloId || docSnap.id,
            name: data.nome || data.rawModuleData.name,
            key: data.codigo || data.rawModuleData.key,
            description: data.descricao || data.rawModuleData.description,
            status: data.ativo ? 'Ativo' : 'Inativo'
          });
        } else {
          list.push({
            id: data.moduloId || docSnap.id,
            key: data.codigo,
            name: data.nome,
            category: 'Recrutamento',
            description: data.descricao,
            status: data.ativo ? 'Ativo' : 'Inativo',
            isCore: false,
            activeTenantsCount: 1,
            iconName: 'Sliders'
          });
        }
      });
      return list;
    }
  } catch (err: any) {
    console.warn('Erro ao buscar módulos do Firestore:', err?.message || err);
  }

  return [];
}

export async function saveModuloFirestore(moduleData: PlatformModule): Promise<void> {
  const moduloId = moduleData.id || `mod-${Date.now()}`;
  const docRef = doc(db, COLLECTIONS.MODULOS, moduloId);

  const docData: ModuloFirestoreDoc = {
    moduloId,
    nome: moduleData.name,
    codigo: moduleData.key,
    descricao: moduleData.description,
    ativo: moduleData.status === 'Ativo',
    rawModuleData: {
      ...moduleData,
      id: moduloId
    }
  };

  try {
    await setDoc(docRef, sanitizeFirestoreData(docData), { merge: true });
  } catch (err) {
    console.error('Erro ao salvar módulo no Firestore:', err);
  }
}

// ----------------------------------------------------------------------------
// RELAÇÃO EMPRESA X MÓDULO (empresa_modulos)
// ----------------------------------------------------------------------------
export async function saveEmpresaModuloFirestore(
  empresaId: string, 
  moduloId: string, 
  ativo: boolean
): Promise<void> {
  const docId = `${empresaId}_${moduloId}`;
  const docRef = doc(db, COLLECTIONS.EMPRESA_MODULOS, docId);

  const data: EmpresaModuloDoc = {
    id: docId,
    empresaId,
    moduloId,
    ativo,
    dataLiberacao: new Date().toISOString()
  };

  try {
    await setDoc(docRef, sanitizeFirestoreData(data), { merge: true });
  } catch (err) {
    console.error('Erro ao salvar permissão de módulo no Firestore:', err);
  }
}

export async function fetchEmpresaModulosFirestore(empresaId: string): Promise<Record<string, boolean>> {
  if (!empresaId) return {};
  try {
    return await fetchCompanyReleasedModules(empresaId);
  } catch (err: any) {
    console.warn('Informação de empresa_modulos indisponível no Firestore:', err?.message || err);
  }

  return {};
}

// ----------------------------------------------------------------------------
// USUÁRIOS
// ----------------------------------------------------------------------------
export async function saveUsuarioFirestore(userDoc: UsuarioFirestoreDoc): Promise<void> {
  if (!auth.currentUser) {
    console.warn('Firebase Auth client não está autenticado. Salvamento no Firestore via client ignorado.');
    return;
  }
  try {
    const docRef = doc(db, COLLECTIONS.USUARIOS, userDoc.uid);
    const sanitized = sanitizeFirestoreData(userDoc);
    await setDoc(docRef, sanitized, { merge: true });

    // Also sync to `users` collection for compatibility
    const usersDocRef = doc(db, 'users', userDoc.uid);
    await setDoc(usersDocRef, sanitizeFirestoreData({
      ...sanitized,
      displayName: userDoc.nome,
      companyId: userDoc.empresaId
    }), { merge: true });
  } catch (err) {
    console.warn(`Aviso ao salvar usuário (${userDoc.uid}) no Firestore:`, err);
  }
}

export async function fetchUsuarioFirestore(uid: string): Promise<UsuarioFirestoreDoc | null> {
  try {
    const docRef = doc(db, COLLECTIONS.USUARIOS, uid);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as UsuarioFirestoreDoc;
    }

    // Check `users` collection as fallback
    const usersRef = doc(db, 'users', uid);
    const usersSnap = await getDoc(usersRef);
    if (usersSnap.exists()) {
      const uData = usersSnap.data();
      return {
        uid,
        nome: uData.nome || uData.displayName || uData.email?.split('@')[0] || 'Usuário',
        email: uData.email,
        role: uData.role,
        tipoUsuario: uData.tipoUsuario || (uData.role === 'MASTER' ? 'MASTER' : 'EMPRESA'),
        empresaId: uData.empresaId || uData.companyId || null,
        ativo: uData.ativo ?? (uData.status !== 'Inativo' && uData.status !== 'Bloqueado'),
        status: uData.status || (uData.ativo ? 'Ativo' : 'Inativo'),
        permissions: uData.permissions || []
      };
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `${COLLECTIONS.USUARIOS}/${uid}`);
  }
  return null;
}

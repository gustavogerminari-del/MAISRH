# Correção manual — Entrevistas e Contratações

Arquivos alterados:

- `src/services/JobCandidateService.ts`
- `src/jobs/components/CandidateDrawerPanel.tsx`

Principais ajustes:

1. A gravação aguarda o Firebase Auth disponibilizar um usuário real antes de escrever no Firestore.
2. O `companyId` passa a ser resolvido pelo perfil autenticado em `usuarios/{uid}` ou `users/{uid}`.
3. Foi removido o fallback incorreto que utilizava o ID da candidatura como ID da empresa.
4. O destino escolhido no modal (`departamento_pessoal` ou `headhunter`) é preservado também no fluxo de repetição.
5. A entrevista agora é salva de forma atômica em `candidate_applications` e na coleção oficial `entrevistas`.
6. A gravação duplicada na coleção `interviews` foi removida do fluxo de agendamento.
7. O encaminhamento para DP/Financeiro é executado uma única vez pelo serviço de contratação.
8. A atualização antecipada da vaga antes da contratação foi removida; o destino é persistido pelo fluxo principal.

Validação executada:

- Verificação de sintaxe TypeScript/TSX dos dois arquivos alterados: aprovada.
- O `npm install` não pôde ser concluído no ambiente de correção porque o registro interno não possui o pacote `@google/genai`; portanto, o build completo deve ser executado no computador do projeto.

Comandos para testar no computador:

```cmd
cd /d "F:\SISTEMA DE RH\MAISRH-main"
npm run lint
npm run dev
```

Fluxos de teste:

- Agendar entrevista, abrir a área lateral Entrevistas e atualizar a página.
- Contratar para Departamento Pessoal e verificar Contratações/Fila de Admissão.
- Contratar para Headhunter e verificar Contratações/Financeiro.
